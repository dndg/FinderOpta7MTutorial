#include <Arduino.h>
#include <ArduinoModbus.h>
#include <ArduinoRS485.h>
#include <math.h>
#include "finder-7m.h"
#include "config.h"
#include "thingProperties.h"

void setup()
{
    Serial.begin(9600);

    RS485.setDelays(PREDELAY, POSTDELAY);
    ModbusRTUClient.setTimeout(TIMEOUT);
    ModbusRTUClient.begin(BAUDRATE, SERIAL_8N1);

    initProperties();
    ArduinoCloud.begin(ArduinoIoTPreferredConnection);
}

void loop()
{
    uint32_t runTime = modbus7MRead32(ADDRESS, REG_RUN_TIME);
    uint32_t energy = modbus7MRead32(ADDRESS, REG_ENERGY);
    uint32_t frequency = modbus7MRead32(ADDRESS, REG_FREQUENCY);
    uint32_t voltage = modbus7MRead32(ADDRESS, REG_VOLTAGE);
    uint32_t activePower = modbus7MRead32(ADDRESS, REG_ACTIVE_POWER);

    Serial.print("Run time = " + (runTime != INVALID_DATA ? String(runTime) : String("read error")));
    Serial.print(", Energy = " + (energy != INVALID_DATA ? String((float)energy) : String("read error!")));
    Serial.print(", Frequency = " + (frequency != INVALID_DATA ? String(convertT5(energy)) : String("read error!")));
    Serial.print(", Voltage = " + (voltage != INVALID_DATA ? String(convertT5(voltage)) : String("read error!")));
    Serial.println(", Active power = " + (activePower != INVALID_DATA ? String(convertT6(activePower)) : String("read error!")));

    if (energy != INVALID_DATA)
    {
        cloudEnergy = (float)energy;
        ArduinoCloud.update();
    }

    delay(1000);
}

uint32_t modbus7MRead32(uint8_t address, uint16_t reg)
{
    ModbusRTUClient.requestFrom(address, INPUT_REGISTERS, reg, 2);
    uint32_t data1 = ModbusRTUClient.read();
    uint32_t data2 = ModbusRTUClient.read();
    if (data1 != INVALID_DATA && data2 != INVALID_DATA)
    {
        return data1 << 16 | data2;
    }
    else
    {
        return INVALID_DATA;
    }
}

float convertT5(uint32_t n)
{
    uint32_t s = (n & 0x80000000) >> 31;
    int32_t e = (n & 0x7F000000) >> 24;
    if (s == 1)
    {
        e = e - 0x80;
    }
    uint32_t m = n & 0x00FFFFFF;
    return (float)m * pow(10, e);
}

float convertT6(uint32_t n)
{
    uint32_t s = (n & 0x80000000) >> 31;
    int32_t e = (n & 0x7F000000) >> 24;
    if (s == 1)
    {
        e = e - 0x80;
    }
    uint32_t ms = (n & 0x00800000) >> 23;
    int32_t mv = (n & 0x007FFFFF);
    if (ms == 1)
    {
        mv = mv - 0x800000;
    }
    return (float)mv * pow(10, e);
}
