// Configurazione
#define ADDRESS 1
#define BAUDRATE 38400
#define PREDELAY 1750
#define POSTDELAY 1750
#define TIMEOUT 1000

// Registri
#define REG_RUN_TIME 103     // Run time
#define REG_FREQUENCY 105    // Frequency
#define REG_VOLTAGE 107      // Voltage U1
#define REG_ACTIVE_POWER 140 // Active Power
#define REG_ENERGY 406       // MID certified active energy

// Errore di lettura
#define INVALID_DATA 0xFFFFFFFF
