#define WIFI_SECRET_SSID "YOUR SSID"
#define WIFI_SECRET_PASSWORD "YOUR PASSWORD"

#define READ_INTERVAL_SECONDS 10

// ArduinoCloud specific configuration
#define ARDUINO_CLOUD_USE_WIFI 1
